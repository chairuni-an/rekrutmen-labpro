Program sederhana yang dibuat menerapkan pengolahan database, flash data, templating, dan penerapan MVC.
Cara menjalankan program (harus memiliki xampp) :
- Copy direktori Eksplorasi2 ke xampp/htdocs/
- Copy direktori test ke mysql/data/
- Jalankan aplikasi xampp_start
- Ketik localhost/Eksplorasi2/ pada browser