<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{	
		$data = $this->mymodel->getMahasiswa();
		$this->load->view('tabel', array('data' => $data));
		/*
		$data = $this->mymodel->getMahasiswa();
		foreach ($data as $test)
		{
			echo "ID : ".$test['ID']."<br />";
		}
		*/
		/*
		$data = $this->db->query('select * from asuransi');
		foreach ($data->result_array() as $test)
		{
			echo "ID : ".$test['ID']."<br />";
		}*/
		/*
		$data = array(
			'id' => 'XtremeKidz',
			'no_id' => '123'
		);
		$this->load->view('welcome_message', $data);
		*/
		//echo base_url();
	}

	public function panggil()
	{
		$data =$this->db->query("select * from mahasiswa");
		/*
		echo "<pre>";
		print_r($data);
		echo "</pre>"; */
		echo "Jumlah data :".$data->num_rows()."<br/>";
		echo "<hr/>";
		$row = $data->row();
		echo "ID :".$row->ID."<br/>";
		echo "Nama :".$row->Nama."<br/>";
		/*
		foreach($data->result() as $row)
		{
			echo "ID :".$row->ID."<br/>";
			echo "Nama :".$row->Nama."<br/>";
			echo "<hr />";
		}
		echo "<hr/>";
		*/
		/*
		foreach($data->result_array() as $row)
		{
			echo "ID :".$row['ID']."<br/>";
			echo "Nama :".$row['Nama']."<br/>";
			echo "<hr />";
		}
		*/
	}

	public function insert()
	{
		$res = $this->mymodel->insertData('mahasiswa', array(
			"ID" => "003",
			"Nama" => "abc",
		));
		if ($res >= 1)
		{
			echo "<h2>Insert data sukses</h2>";
		}
		else
		{
			echo "<h2>Insert data gagal</h2>";
		}
	}
	
	public function update()
	{
		$res = $this->mymodel->updateData('mahasiswa', array(
			"Nama" => "yolo",
		),array('ID' => "001"));
		if ($res >= 1)
		{
			echo "<h2>Update data sukses</h2>";
		}
		else
		{
			echo "<h2>Update data gagal</h2>";
		}
	}
	
	public function delete()
	{
		$res = $this->mymodel->deleteData('mahasiswa',array('ID' => "001"));
		if ($res >= 1)
		{
			echo "<h2>Delete data sukses</h2>";
		}
		else
		{
			echo "<h2>Delete data gagal</h2>";
		}
	}
	
	public function cetak($satu = '1', $dua = '2')
	{
		echo 'parameter pertama '.$satu.'<br/>';
		echo 'parameter kedua '.$dua.'<br/>';
	}
}
