<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function index()
	{	
		$data = $this->mymodel->getMahasiswa();
		$this->load->view("index",array('data' => $data));
	}

	public function about()
	{
		$this->load->view("about");
	}

	public function html_sidebar()
	{
		return $this->load->view("tooplate_sidebar", array(), true);
	}

	public function html_footer()
	{
		return $this->load->view("tooplate_footer_wrapper", array(), true);
	}
}
