<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	public function index()
	{
		$data = $this->mymodel->getMahasiswa();
		$this->load->view('tabel', array('data' => $data));
	}

	public function add_data()
	{
		$this->load->view('indexAdd');
	}

	public function do_insert()
	{
		$ID = $_POST['ID'];
		$Nama = $_POST['Nama'];
		$data_insert = array(
			'ID' => $ID,
			'Nama' => $Nama,
		);
		$res = $this->mymodel->insertData('mahasiswa',$data_insert);
		if ($res >= 1)
		{
			$this->session->set_flashdata('pesan','Insert data sukses');
			redirect('web/index');
		}
		else
		{
			$this->session->set_flashdata('pesan','Insert data gagal');
			redirect('web/index');
		}
	}

	public function edit_data($ID)
	{
		$temp = $this->mymodel->getMahasiswa("where ID = '$ID'");
		$data = array(
			"ID" => $temp[0]['ID'],
			"Nama" => $temp[0]['Nama'],		
		);
		$this->load->view('indexEdit',$data);
	}

	public function do_update()
	{
		$ID = $_POST['ID'];
		$Nama = $_POST['Nama'];
		$data_update = array(
			'Nama' => $Nama,
		);
		$res = $this->mymodel->updateData('mahasiswa',$data_update,array('ID' => $ID));
		if ($res >= 1)
		{
			$this->session->set_flashdata('pesan','Update data sukses');
			redirect('web/index');
		}
	}

	public function do_delete($ID)
	{
		$res = $this->mymodel->deleteData('mahasiswa', array('ID' => $ID));
		if ($res >= 1)
		{
			$this->session->set_flashdata('pesan','Delete data sukses');
			redirect('web/index');
		}
	}
}
