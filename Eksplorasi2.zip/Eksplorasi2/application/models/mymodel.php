<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mymodel extends CI_Model 
{
	public function getMahasiswa($where="")
	{
		$data = $this->db->query('select * from mahasiswa '.$where);
		return $data->result_array();
	}
	
	public function insertData($tabelName,$data)
	{
		$res = $this->db->insert($tabelName,$data);
		return $res;
	}
	
	public function updateData($tabelName,$data,$where)
	{
		$res = $this->db->update($tabelName,$data,$where);
		return $res;
	}
	
	public function deleteData($tabelName,$where)
	{
		$res = $this->db->delete($tabelName,$where);
		return $res;
	}
}
