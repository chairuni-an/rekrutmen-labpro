<html>
	<head>
		<title>Data mahasiswa</title>
	</head>
	<body>
	<form method="POST" action="<?php echo base_url()."index.php/crud/do_insert" ?>">
		<table>
			<tr>
				<td>ID</td>
				<td><input type="text" name="ID" /></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="Nama" /></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btnSubmit" value="Submit" /></td>
			</tr>
		</table>
	</form>
	</body>
</html>