<html>
	<head>
		<title>Data mahasiswa</title>
	</head>
	<body>
	<?php echo "<h2>".$this->session->flashdata('pesan')."</h2>" ?>
		<table border="1" style="border-collapse:collaptse"; width="50%">
			<tr style="background:gray">
				<th>ID</th>
				<th>Nama</th>
				<th>Action</th>
			</tr>
			<?php foreach($data as $test){ ?> 
				<tr>
					<td><?php echo $test['ID']; ?></td>
					<td><?php echo $test['Nama']; ?></td>
					<td align="center">
						<a href="<?php echo base_url()."index.php/crud/edit_data/".$test['ID']; ?>">Edit</a> ||
						<a href="<?php echo base_url()."index.php/crud/do_delete/".$test['ID']; ?>">Delete</a>
					</td>
				</tr>
			<?php } ?>
		</table>
		<a href="<?php echo base_url()."index.php/crud/add_data/"; ?>">
			Tambah Data
		</a>
	</body>
</html>