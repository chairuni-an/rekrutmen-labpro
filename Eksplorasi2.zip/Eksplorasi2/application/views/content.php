<div id="tooplate_content">
           		<div id="homepage_slider">
                    <div id="slider">
                        <a href="#"><img src="<?php echo base_url()."assets/"; ?>images/slideshow/01.jpg" alt="Slide 01" title="Nam fermentum lacus suscipit diam feugiat fringilla." /></a>
                        <a href="#"><img src="<?php echo base_url()."assets/"; ?>images/slideshow/02.jpg" alt="Slide 02" title="Proin bibendum est id velit tincidunt ut sodales ligula facilisis." /></a>
                        <a href="#"><img src="<?php echo base_url()."assets/"; ?>images/slideshow/03.jpg" alt="Slide 03" title="Fusce tincidunt diam eu metus iaculis hendrerit." /></a>
                        <a href="#"><img src="<?php echo base_url()."assets/"; ?>images/slideshow/04.jpg" alt="Slide 04" title="Nulla faucibus luctus quam eget placerat. " /></a>
                        <a href="#"><img src="<?php echo base_url()."assets/"; ?>images/slideshow/05.jpg" alt="Slide 05" title="Aliquam quis velit et sem vestibulum dignissim." /></a>
                    </div>
                </div>
                
                <div class="post_box">
                	<div class="date_box">
                    	<div class="date">19<span>OCT 2048</span></div>
                        <div class="post_comment">123 comments</div>
                    </div>
					
                    <div class="post_box_right">
                        <h2>Free Website Templates</h2>
                        <div class="post_meta"><a href="#">Graphics</a> \ <a href="#">Illustrations</a></div>
                		<img src="<?php echo base_url()."assets/"; ?>images/tooplate_image_01.jpg" alt="Image 01" />
                        <p>Elegant is a <a rel="nofollow" href="http://www.tooplate.com" target="_parent">free website template</a> for everyone. Credits go to <a rel="nofollow" href="http://www.photovaco.com" target="_blank">PhotoVaco</a> for photos and <a rel="nofollow" href="http://nivo.dev7studios.com" target="_blank">Dev7Studios</a> for Nivo Slider. Integer ultrices enim non ipsum pulvinar, sed tincidunt ipsum lacinia.</p>
                         <a href="blog_post.html" class="more float_r">Continue Reading</a>
                    </div>
					
                    <div class="cleaner"></div>
				</div>
                
                <div class="post_box post_box_last">
                	<div class="date_box">
                    	<div class="date">16<span>OCT 2048</span></div>
                        <div class="post_comment">174 comments</div>
                    </div>
					
                    <div class="post_box_right">
                        <h2>Web Design Trends </h2>
                        <div class="post_meta"><a href="#">Web Design</a> \ <a href="#">Templates</a></div>
                		<img src="<?php echo base_url()."assets/"; ?>images/tooplate_image_02.jpg" alt="Image 02" />
                		<p>Vestibulum turpis tellus, ornare accumsan viverra et, varius at dui. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ut ipsum enim, quis aliquam odio. Vivamus cursus vestibulum sodales. Nulla facilisi. Proin at neque in tellus malesuada mattis.</p>
                         <a href="blog_post.html" class="more float_r">Continue Reading</a>
                    </div>
					
                    <div class="cleaner"></div>
				</div>
                
            <div class="cleaner"></div>
        </div>
        