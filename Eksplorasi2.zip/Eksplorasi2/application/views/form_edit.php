<html>
	<head>
		<title>Data mahasiswa</title>
	</head>
	<body>
	<form method="POST" action="<?php echo base_url()."index.php/crud/do_update" ?>">
		<table>
			<tr>
				<td>ID</td>
				<td><input type="text" name="ID" value="<?php echo $ID; ?>" readonly /></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="Nama" value="<?php echo $Nama; ?>" /></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btnSubmit" value="Submit" /></td>
			</tr>
		</table>
	</form>
	</body>
</html>