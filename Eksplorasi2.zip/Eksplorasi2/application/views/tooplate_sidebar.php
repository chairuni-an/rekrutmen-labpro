<div id="tooplate_sidebar">
        	<div class="sidbar_box">
		    	<a href="#"><img src="<?php echo base_url()."assets/"; ?>images/tooplate_250x250_ad.jpg" alt="250x250 ad" /></a>
			</div>
			
            <div class="sidbar_box">
		        <h4>Categories</h4>
                <ul class="tooplate_list">
                    <li><a href="index.html">Aliquam ut arcu a metus</a></li>
                    <li><a href="index.html">Donec eu ipsum lectus</a></li>
                    <li><a href="index.html">Fusce at mauris massa</a></li>
                    <li><a href="index.html">Mauris eleifend elit nec</a></li>
                    <li><a href="index.html">Phasellus posuere ipsum</a></li>
                    <li><a href="index.html">Sed venenatis dui eget</a></li>
                </ul>
			</div>
			
            <div class="sidbar_box">
		        <h4>Recent comments</h4>
                <div class="recent_comment_box">
                    <a href="#">Maecenas vel ligula dolor</a>
                    <p>Curabitur pellentesque varius nibh, sit amet ultrices urna lobortis ac.</p>
                </div>
                
                <div class="recent_comment_box">
                    <a href="#">Aenean feugiat mattis </a>
                    <p>Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
                </div>
                
                <div class="recent_comment_box last_recent_comment_box">
                    <a href="#"> Lacus enim id lacinia in</a>
                    <p>Curabitur ullamcorper ultricies nisi.  Nam eget dui. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> and <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                </div>	
			</div>
			
            <div class="cleaner"></div>
        </div>
        