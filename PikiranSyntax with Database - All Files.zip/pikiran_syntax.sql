-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2016 at 12:42 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pikiran_syntax`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
`id_artikel` int(5) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi_artikel` tinytext NOT NULL,
  `id_kategori` int(3) NOT NULL,
  `jumlah_baca` int(5) NOT NULL,
  `create_by` int(11) NOT NULL,
  `create_time` varchar(10) NOT NULL,
  `update_by` int(11) NOT NULL,
  `update_time` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `judul`, `isi_artikel`, `id_kategori`, `jumlah_baca`, `create_by`, `create_time`, `update_by`, `update_time`) VALUES
(4, 'Artikel Asal', 'apa aj', 2, 22, 2, '1466526774', 2, '1466526783'),
(7, 'Lirik Doraemon :)', 'Aku ingin begini\r\nAku ingin begitu\r\nIngin ini ingin itu banyak sekaliiiiii', 2, 139, 2, '1467989003', 2, '1469285997'),
(8, 'admin', 'ini posnya admin', 1, 102, 4, '1469246953', 2, '1469279481'),
(9, 'a', 'aa', 1, 0, 2, '1469801231', 2, '1469801231'),
(10, '5', '5', 1, 0, 2, '1469801239', 2, '1469801239'),
(11, '6', '6\r\n', 1, 0, 2, '1469801251', 2, '1469801251'),
(12, '7', '7', 1, 0, 2, '1469801259', 2, '1469801259'),
(13, '8', '8', 1, 0, 2, '1469801272', 2, '1469801272'),
(14, '9', '9', 1, 0, 2, '1469801278', 2, '1469801278'),
(15, '10', '10', 1, 0, 2, '1469801284', 2, '1469801284'),
(16, '11', '11', 1, 0, 2, '1469801290', 2, '1469801290'),
(17, '12', '12', 1, 0, 2, '1469801297', 2, '1469801297'),
(18, '13', '13', 1, 0, 2, '1469801302', 2, '1469801302'),
(19, '14', '14', 1, 0, 2, '1469801307', 2, '1469801307'),
(20, '15', '15', 1, 0, 2, '1469801313', 2, '1469801313'),
(21, '16', '16', 1, 0, 2, '1469801318', 2, '1469801318'),
(22, '17', '17', 1, 0, 2, '1469801330', 2, '1469801330'),
(23, '18', '18', 1, 0, 2, '1469801337', 2, '1469801337'),
(24, '19', '19', 1, 0, 2, '1469801343', 2, '1469801343'),
(25, '20', '20', 1, 0, 2, '1469801348', 2, '1469801348'),
(26, '21', '21', 1, 17, 2, '1469801354', 2, '1469801354'),
(27, 'Checkpoint 1', 'Rilis: 14 Juni 2016\r\nDeadline: 10 Juli 2016\r\nDeliverables: Source code dan screenshot dari aplikasi, serta progress report\r\nDi akhir tahap ini, Anda sudah harus menyelesaikan sebagian dari aplikasi anda. Diwajibkan untuk melakukan asistensi minimal satu k', 1, 1, 2, '1470549306', 2, '1470549306'),
(28, 'Checkpoint 2', 'Rilis: 12 Juli 2016\r\nDeadline: 7 Agustus 2016\r\nDeliverables: Source code dan screenshot dari aplikasi, serta progress report\r\nDi akhir tahap ini, aplikasi Anda sudah harus hampir selesai. Pastikan bahwa hanya hal-hal minor yang belum selesai, misalnya pol', 1, 21, 2, '1470549355', 2, '1470549355');

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', '1', 1469246797),
('Admin', '4', 1469246941),
('User', '2', 1469246806),
('User', '3', 1470550691),
('User', '5', 1470551457),
('User', '6', 1470551574);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/artikel/*', 2, NULL, NULL, NULL, 1469243412, 1469243412),
('/kategori/*', 2, NULL, NULL, NULL, 1469243416, 1469243416),
('/komentar/*', 2, NULL, NULL, NULL, 1469243420, 1469243420),
('/user/*', 2, NULL, NULL, NULL, 1469243426, 1469243426),
('Admin', 1, 'Admin', NULL, NULL, 1469246532, 1469246532),
('updateOwnPost', 2, 'Update own post', 'onlyAuthor', NULL, 1469246436, 1469246436),
('updatePost', 2, 'Update post', NULL, NULL, 1469246345, 1469246345),
('User', 1, 'User', NULL, NULL, 1469246642, 1469246642);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('Admin', '/artikel/*'),
('User', '/artikel/*'),
('Admin', '/kategori/*'),
('User', '/kategori/*'),
('Admin', '/komentar/*'),
('User', '/komentar/*'),
('Admin', '/user/*'),
('User', '/user/*'),
('User', 'updateOwnPost'),
('Admin', 'updatePost'),
('updateOwnPost', 'updatePost');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_rule`
--

INSERT INTO `auth_rule` (`name`, `data`, `created_at`, `updated_at`) VALUES
('onlyAuthor', 'O:25:"frontend\\rules\\OnlyAuthor":3:{s:4:"name";s:10:"onlyAuthor";s:9:"createdAt";i:1469246248;s:9:"updatedAt";i:1469246256;}', 1469246248, 1469246256);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
`id_kategori` int(3) NOT NULL,
  `nama_kategori` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Otomotif'),
(2, 'Teknologi'),
(3, 'Politik');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
`id_komentar` int(3) NOT NULL,
  `id_artikel` int(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  `isi_komentar` tinytext NOT NULL,
  `create_time` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`id_komentar`, `id_artikel`, `id_user`, `isi_komentar`, `create_time`) VALUES
(7, 4, 2, 'Komentar baru', 1467984103),
(8, 7, 2, 'La la la\r\nAku sayang sekali\r\nDoraemon', 1467989025),
(9, 8, 4, 'adsf', 1469282178),
(13, 8, 2, 'adf', 1469284779),
(15, 28, 4, 'waduh deadline', 1470555559),
(16, 28, 2, 'dasar\r\nhahaha', 1470555587),
(17, 8, 2, 'coba nambah komen', 1471077795),
(18, 7, 2, '<3', 1471077824);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1469241126),
('m140506_102106_rbac_init', 1469241133);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `first_name`, `last_name`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Ade Yusuf', 'Rahardian', 'adeyura', 'feddfrLq3LCI7GcCXWZMZpMr6YW9KEXy', '$2y$13$1QLePDg5oZLrg5xjnnY2GecZ447N16gwvyc2tabisYg0vhlMXFepu', 'qXF8O-hj9FqwkFR6HqEA72MNmNaQxDv7_1466005613', 'ade.yusuf.r@gmail.com', 10, 1448180898, 1466005613),
(2, 'Ade', 'Yusuf', 'testing', 'e2lViT5gmuE5sin2M6YHyCGMKPmrsxao', '$2y$13$7d.Fiuml3.rGqWUREce1EOcnedkm33BdVOURO8kW0kurQMgQDtOze', NULL, 'testing@testing.com', 10, 1466005747, 1471256782),
(3, 'ade', 'yura', 'ade yura', 'bvm_Q2F811aDH9Jvk05gn5qwxJvGvQ4V', '$2y$13$t3w2vM78sQBu5K36lSImu.b3RLS4y3AHqOwiNU3LdBOM1s8t6BxR6', NULL, 'adeyura@adeyura.com', 10, 1466238141, 1466238141),
(4, 'admin', 'admin', 'admin', 'e1FYTgABWNGnUTtcwL7Kga2FgTGKBxjp', '$2y$13$LPucncMfGnSvVJ5Y.8WF7uRoUF18XLYzxZc6M5rE5n1m6WSg1qfvS', NULL, 'admin@admin.com', 10, 1469246911, 1469246911),
(5, 'aaaaaa', 'aaaaaa', 'aaaaaa', 'uXS49qwgQF1bSMe0NqVYOiaaVlNjQLrO', '$2y$13$yiGYR/8yFCMz1ca41ekUzONG7U7G/E1gtOnZ4Ibl7T0WOw1vnsWty', NULL, 'aaaaaa@aaaaaa.com', 10, 1470551423, 1471256691);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
 ADD PRIMARY KEY (`id_artikel`), ADD KEY `id_kategori` (`id_kategori`), ADD KEY `create_by` (`create_by`), ADD KEY `update_by` (`update_by`);

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
 ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
 ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
 ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
 ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
 ADD PRIMARY KEY (`id_komentar`), ADD KEY `id_artikel` (`id_artikel`), ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
 ADD PRIMARY KEY (`version`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
MODIFY `id_artikel` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
MODIFY `id_kategori` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
MODIFY `id_komentar` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `artikel`
--
ALTER TABLE `artikel`
ADD CONSTRAINT `artikel_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`),
ADD CONSTRAINT `artikel_ibfk_2` FOREIGN KEY (`create_by`) REFERENCES `user` (`id`),
ADD CONSTRAINT `artikel_ibfk_3` FOREIGN KEY (`update_by`) REFERENCES `user` (`id`);

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `komentar`
--
ALTER TABLE `komentar`
ADD CONSTRAINT `komentar_ibfk_1` FOREIGN KEY (`id_artikel`) REFERENCES `artikel` (`id_artikel`) ON DELETE CASCADE,
ADD CONSTRAINT `komentar_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
