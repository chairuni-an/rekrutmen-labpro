<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index() {
		$this->login();
	}

	public function register() {
		$data = new stdClass();

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[4]|max_length[20]|is_unique[users.username]', array('is_unique' => 'This username already exists. Please choose another username.'));
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]', array('is_unique' => 'This email already being used. Please choose another email'));
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'required|min_length[6]|matches[password]');

		if ($this->form_validation->run() === true) {
			$name = $this->input->post('name');
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$password = $this->input->post('password');

			if ($this->user_model->create_user($username, $name, $email, $password)) {
				$this->load->view('header');
				$this->load->view('user/register/register_success');
			}
			else {
				$data->error = 'There was a problem creating your new account. Please try again.';

				$this->load->view('header');
				$this->load->view('user/register/register', $data);
			}
		}
		else {
			$this->load->view('header');
			$this->load->view('user/register/register');
		}
	}

	public function login() {
		$data = new stdClass();

		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if ($this->form_validation->run() == true) {
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			if ($this->user_model->check_login($username, $password)) {
				$user_id = $this->user_model->get_id_from_username($username);
				$user = $this->user_model->get_user($user_id);

				$_SESSION['user_id'] = (int)$user->id;
				$_SESSION['username'] = (string)$user->username;
				$_SESSION['logged_in'] = (bool)true;;
				$_SESSION['is_admin'] = (bool)$user->is_admin;

				redirect(base_url());
			}
			else {
				$data->error = "Wrong username and password.";

				$this->load->view('header');
				$this->load->view('user/login/login', $data);
			}
		}
		else {
			$this->load->view('header');
			$this->load->view('user/login/login');
		}
	}

	public function logout() {
		$data = new stdClass();

		if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
			foreach ($_SESSION as $key => $value) {
				unset($_SESSION[$key]);
			}

			$this->load->view('header');
			$this->load->view('user/logout/logout_success');
		}
		else {
			redirect('/');
		}
	}

	public function profile($username) {
		$data = new stdClass();

		$user_id = $this->user_model->get_id_from_username($username);
		$user = $this->user_model->get_user($user_id);
		$user->last_post = $this->user_model->get_user_last_post($user_id);
		$user->count_topics = $this->user_model->count_user_topics($user_id);
		$user->count_posts = $this->user_model->count_user_posts($user_id);

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li class="active">' . $username . '</li>';
		$breadcrumb .= '</ol>';

		$data->user = $user;
		$data->breadcrumb = $breadcrumb;

		$this->load->view('header');
		$this->load->view('user/profile/profile', $data);
	}

	public function edit_profile($username) {
		$data = new stdClass();

		$password_required_if = $this->input->post('password') ? '|required' : '';
		$this->form_validation->set_rules('name', 'Name', '');
		$this->form_validation->set_rules('username', 'Username', 'alpha_numeric|min_length[4]|max_length[20]|is_unique[users.username]', array('is_unique' => 'This username already exists. Please choose another username.'));
		$this->form_validation->set_rules('email', 'Email', 'valid_email|is_unique[users.email]', array('is_unique' => 'This email already being used. Please choose another email'));
		$this->form_validation->set_rules('current_password', 'Current Password', 'trim' . $password_required_if . '|callback_verify_current_password');
		$this->form_validation->set_rules('password', 'New Password', 'min_length[6]|matches[password_confirm]');
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'min_length[6]');

		$user_id = $this->user_model->get_id_from_username($username);
		$user = $this->user_model->get_user($user_id);

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li><a href="' . base_url('user/profile/' . $username) . '">' . $username . '</a></li>';
		$breadcrumb .= '<li class="active">Edit Profile</li>';
		$breadcrumb .= '</ol>';

		$data->user = $user;
		$data->breadcrumb = $breadcrumb;

		if ($this->form_validation->run() === true) {
			$update_data = [];

			if ($this->input->post('name') != '') {
				$update_data['name'] = $this->input->post('name');
			}
			if ($this->input->post('username') != '') {
				$update_data['username'] = $this->input->post('username');
			}
			if ($this->input->post('email') != '') {
				$update_data['email'] = $this->input->post('email');
			}
			if ($this->input->post('password') != '') {
				$update_data['password'] = $this->input->post('password');
			}

			if (isset($_FILES['userfile']['name']) && !empty($_FILES['userfile']['name'])) {

				$config['upload_path']      = './uploads/avatars/';
				$config['allowed_types']    = 'gif|jpg|png';
				
				$config['file_ext_tolower'] = true;
				$config['encrypt_name']     = true;	

				$this->load->library('upload', $config);
				if (!$this->upload->do_upload()) {
					$error = array('error' => $this->upload->display_errors());
					$this->load->view('upload_form', $error);
				} 
				else {
					$update_data['avatar'] = $this->upload->data('file_name');					
				}
			}

			if ($this->user_model->update_user($user_id, $update_data)) {
				if (isset($update_data['username'])) {
					$_SESSION['username'] = $update_data['username'];

					if ($this->input->post('username') != '') {
						$_SESSION['flash'] = 'Your profile has been succesfully updated';
					}
				}

				if (isset($update_data['avatar'])) {
					$data->user->avatar = $update_data['avatar'];
				}

				if ($this->input->post('username') != '') {
					redirect(base_url('user/edit_profile/'.$update_data['username']));
				}
				else {
					redirect(base_url('user/edit_profile/'.$_SESSION['username']));
				}
			}
			else {
				$data->error = 'There was a problem updating your account. Please try again.';

				$this->load->view('header');
				$this->load->view('user/profile/edit_profile', $data);
			}
		}
		else {
			$this->load->view('header');
			$this->load->view('user/profile/edit_profile', $data);
		}
	}

	public function verify_current_password($str) {
		if ($str != '') {
			if ($this->user_model->check_login($_SESSION['username'], $str) === true) {
				return true;
			}

			$this->form_validation->set_message('verify_current_password', 'The {field} field does not match your password.');
			return false;
		}
		else {
			return true;
		}
	}

	public function members() {
		$data = new stdClass();

		$users = $this->user_model->get_users();

		foreach ($users as $user) {
			$user->count_topics = $this->user_model->count_user_topics($user->id);
			$user->count_posts = $this->user_model->count_user_posts($user->id);
		}

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li class="active">Members</li>';
		$breadcrumb .= '</ol>';

		$data->users = $users;
		$data->breadcrumb = $breadcrumb;

		$this->load->view('header');
		$this->load->view('user/members/members', $data);
	}

}