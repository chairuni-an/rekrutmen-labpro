<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index() {
		$this->load->view('header');
		$this->load->view('admin/index');
	}

	public function users() {
		$data = new stdClass();

		$users = $this->user_model->get_users();

		$data->users = $users;

		$this->load->view('header');
		$this->load->view('admin/user/users', $data);
	}

	public function edit_user($username) {
		$data = new stdClass();

		$user_id = $this->user_model->get_id_from_username($username);
		$user = $this->user_model->get_user($user_id);

		if ($user->is_admin === '1') {
			$options = '<option value="administrator" selected>Administrator</option>';
			$options .= '<option value="user">User</option>';
		} else {
			$options = '<option value="administrator">Administrator</option>';
			$options .= '<option value="user" selected>User</option>';
		}

		$data->user = $user;
		$data->options = $options;

		$this->form_validation->set_rules('user_rights', 'User Rights', 'required|in_list[administrator,user]', array('in_list' => 'Don\'t try to hack the form!'));

		if ($this->form_validation->run() === true) {
			$rights = $this->input->post('user_rights');

			if ($rights === 'administrator') {
				$is_admin = '1';
			}
			else {
				$is_admin = '0';
			}

			if ($this->admin_model->update_user_rights($user_id, $is_admin)) {
				$data->success = $user->username . ' has successfully been updated.';
			}
			else {
				$data->error = 'There was an error while trying to update this user. Please try again';
			}

			$this->load->view('header');
			$this->load->view('admin/user/edit_user', $data);
		}
		else {
			$this->load->view('header');
			$this->load->view('admin/user/edit_user', $data);
		}
	}

}
