<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function create_user($username, $name, $email, $password) {
		$data = array(
			'username' => $username,
			'name' => $name,
			'email' => $email,
			'password' => password_hash($password, PASSWORD_BCRYPT),
			'created_at' => date('Y-m-j H:i:s'),
		);

		return $this->db->insert('users', $data);
	}

	public function update_user($user_id, $update_data) {
		if (array_key_exists('password', $update_data)) {
			$update_data['password'] = password_hash($update_data['password'], PASSWORD_BCRYPT);
		}

		if (!empty($update_data)) {
			$this->db->where('id', $user_id);
			return $this->db->update('users', $update_data);
		}
		else {
			return false;
		}
	}

	public function check_login($username, $password) {
		$this->db->select('password');
		$this->db->from('users');
		$this->db->where('username', $username);
		$hash = $this->db->get()->row('password');

		return password_verify($password, $hash);
	}

	public function get_id_from_username($username) {
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('username', $username);

		return $this->db->get()->row('id');
	}

	public function get_username_from_id($id) {
		$this->db->select('username');
		$this->db->from('users');
		$this->db->where('id', $id);

		return $this->db->get()->row('username');
	}

	public function get_users() {
		$this->db->select('*');
		$this->db->from('users');

		return $this->db->get()->result();
	}

	public function get_user($id) {
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('id', $id);

		return $this->db->get()->row();
	}

	public function count_user_topics($user_id) {
		$this->db->select('id');
		$this->db->from('topics');
		$this->db->where('user_id', $user_id);

		return $this->db->get()->num_rows();
	}

	public function count_user_posts($user_id) {
		$this->db->select('id');
		$this->db->from('posts');
		$this->db->where('user_id', $user_id);

		return $this->db->get()->num_rows();
	}

	public function get_user_last_post($user_id) {
		$this->db->select('*');
		$this->db->from('posts');
		$this->db->where('user_id', $user_id);
		$this->db->order_by('created_at', 'DESC');
		$this->db->limit(1);

		return $this->db->get()->row();
	}

}