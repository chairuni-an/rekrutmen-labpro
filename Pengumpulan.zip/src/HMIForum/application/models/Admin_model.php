<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

	public function update_user_rights($user_id, $is_admin) {
		$data = array (
			'is_admin' => $is_admin,
		);

		$this->db->from('users');
		$this->db->where('id', $user_id);

		return $this->db->update('users', $data);
	}
	
}
