<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Forum config
|--------------------------------------------------------------------------
|
| This determines the basic forum config
|
*/
$config['site_title'] = 'HMIForum';
$config['site_slogan'] = 'The best forum website for HMIF';
$config['site_email'] = 'mickyyu96@gmail.com';
