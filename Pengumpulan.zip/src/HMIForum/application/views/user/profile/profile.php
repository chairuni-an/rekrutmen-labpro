<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>
		<div class="col-md-12">
			<div class="page-header">
				<h1>
					User profile 
					<?php if ($user->username === $_SESSION['username']) : ?>
						<a href="<?= base_url('user/edit_profile/' . $user->username) ?>" class="btn btn-xs btn-success">Edit your profile</a>
					<?php endif ?>
				</h1>
			</div>
		</div>
		<div class="col-md-12">
			<div class="row">
				<div class="col-sm-3 text-center">
					<img class="avatar" src="<?= base_url('uploads/avatars/' . $user->avatar) ?>">
				</div>
				<div class="col-sm-4 col-sm-offset-0">
					<p>Name: <?= $user->name ?></p>
					<p>Username: <?= $user->username ?></p>
					<p>Email: <?= $user->email ?></p>
					<p>Topic started: <?= $user->count_topics ?></p>
					<p>Post: <?= $user->count_posts ?></p>
					<p>Joined: <?= $user->created_at ?></p>
				</div>
			</div><!-- .row -->
		</div>
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($user); ?>