<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>

		<div class="col-md-12">
			<div class="page-header">
				<h2>Members</h2>
			</div>
		</div>
		
		<div class="col-md-12">
			<table class="table table-striped table-condensed table-hover">
				<thead>
					<tr>
						<th>Name</th>
						<th>Username</th>
						<th>Email</th>
						<th>Topic started</th>
						<th>Post</th>
						<th>Joined</th>
					</tr>
				</thead>
				<tbody>
					<?php if ($users) : ?>
						<?php foreach ($users as $user) : ?>
							<tr>
								<td>
									<p>
										<a href="<?= base_url('user/profile/'.$user->username) ?>"><small><?= $user->name ?></small></a>
									</p>
								</td>
								<td>
									<p>
										<small><?= $user->username ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $user->email ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $user->count_topics ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $user->count_posts ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $user->created_at ?></small>
									</p>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($forums); ?>