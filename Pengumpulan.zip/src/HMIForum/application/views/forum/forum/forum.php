<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>

		<div class="col-md-12">
			<div class="page-header">
				<h2>Announcements & Jobs Offer</h2>
			</div>
		</div>

		<div class="col-md-12">
			<table class="table table-striped table-condensed table-hover">
				<thead>
					<tr>
						<th style="width:40%;">Title</th>
						<th style="width:25%;">Posts</th>
						<th style="width:35%;">Latest Post</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							<p>
								<a href="<?= base_url('announcement') ?>">Announcements</a>
							</p>
						</td>
						<td>
							<p>
								<?= $announcement_count ?>
							</p>
						</td>
						<td>
							<?php if ($announcement_last_post != NULL) : ?>
								<p>
									<a href="<?= base_url('announcement/'.strtolower(url_title($announcement_last_post))) ?>"><?= $announcement_last_post ?></a>
								</p>
							<?php else: ?>
								<p>no post yet</p>
							<?php endif ?>
						</td>
					</tr>
					<tr>
						<td>
							<p>
								<a href="<?= base_url('job_offer') ?>">Jobs Offer</a>
							</p>
						</td>
						<td>
							<p>
								<?= $job_offer_count ?>
							</p>
						</td>
						<td>
							<?php if ($job_offer_last_post != NULL) : ?>
								<p>
									<a href="<?= base_url('job_offer/'.strtolower(url_title($job_offer_last_post))) ?>"><?= $job_offer_last_post ?></a>
								</p>
							<?php else: ?>
								<p>no post yet</p>
							<?php endif ?>
						</td>
					</tr>
				</tbody>					
			</table>
		</div>

		<div class="col-md-12">
			<div class="page-header">
				<h2>Forums</h2>
			</div>
		</div>
		
		<div class="col-md-12">
			<table class="table table-striped table-condensed table-hover">
				<thead>
					<tr>
						<th style="width:35%;">Title</th>
						<th style="width:15%;">Topics</th>
						<th style="width:15%;">Posts</th>
						<th class="hidden-xs" style="width:35%;">Latest topic</th>
					</tr>
				</thead>
				<tbody>
					<?php if ($forums) : ?>
						<?php foreach ($forums as $forum) : ?>
							<tr>
								<td>
									<p>
										<a href="<?= base_url($forum->slug) ?>"><?= $forum->title ?></a><br>
										<small><?= $forum->description ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $forum->count_topics ?></small>
									</p>
								</td>
								<td>
									<p>
										<small><?= $forum->count_posts ?></small>
									</p>
								</td>
								<td class="hidden-xs">
									<?php if ($forum->latest_topic->title !== null) : ?>
										<p>
											<small><a href="<?= base_url($forum->latest_topic->permalink) ?>"><?= $forum->latest_topic->title ?></a><br>by <a href="<?= base_url('user/profile/' . $forum->latest_topic->author) ?>"><?= $forum->latest_topic->author ?></a>, <?= $forum->latest_topic->created_at ?></small>
										</p>
									<?php else : ?>
										<p>
											<small>no topic yet</small>
										</p>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
			
		</div>
		
		<?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) : ?>
			<div class="col-md-12">
				<a href="<?= base_url('create_forum') ?>" class="btn btn-default">Create a new forum</a>
			</div>
		<?php endif; ?>
		
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($forums); ?>