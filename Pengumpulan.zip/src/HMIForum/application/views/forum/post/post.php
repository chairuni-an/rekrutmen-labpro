<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>
		<div class="col-md-12">
			<div class="page-header">
				<h1><?= $topic->title ?></h1>
			</div>
		</div>
		
		<div class="col-md-12">
			<div class="panel panel-success">
				<div class="panel-heading">
					<div style="width:100%; word-wrap:break-word;">
						<?= $topic->content; ?>
					</div>
				</div>
			</div>
		</div>

		<?php foreach ($posts as $post) : ?>
			<div class="col-md-12">
				<article class="panel panel-default">
					<div class="panel-body">
						<header class="post-header">
							<small><a href="<?= base_url('user/profile/' . $post->author) ?>"><?= $post->author ?></a>, <?= $post->created_at ?></small><br>
							<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) : ?>
								<?php if ($post->like_counts > 1) : ?>
									<small>
										<?= $post->like_counts ?> <a href="<?php echo base_url()."index.php/forum/post_like/".$post->id.'/'.$forum->slug.'/'.$topic->slug; ?>">likes</a>
									</small>
								<?php else : ?>
									<small>
										<?= $post->like_counts ?> <a href="<?php echo base_url()."index.php/forum/post_like/".$post->id.'/'.$forum->slug.'/'.$topic->slug; ?>">like</a>
									</small>
								<?php endif; ?>
							<?php else: ?>	
								<?php if ($post->like_counts > 1) : ?> 
									<small><?= $post->like_counts ?> likes</small>
								<?php else : ?>
									<small><?= $post->like_counts ?> like</small>
								<?php endif; ?>
							<?php endif; ?>
						</header>
						<div class="post-content">
							<div style="width:100%; word-wrap:break-word;">
								<?= $post->content ?>
							</div>
						</div>
					</div>
				</article>
			</div>
		<?php endforeach; ?>
		
		<?php if (isset($_SESSION['user_id'])) : ?>
			<div class="col-md-12">
				<a href="<?= base_url($forum->slug . '/' . $topic->slug . '/reply') ?>" class="btn btn-default">Reply to this topic</a>
			</div>
		<?php endif; ?>
		
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($forum, $topic, $posts); ?>