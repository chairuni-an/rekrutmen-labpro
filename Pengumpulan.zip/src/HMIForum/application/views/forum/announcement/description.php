<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>
		
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
					<?php echo str_replace("\n", "<br>", $announcement->description); ?>
				</div>
			</div>
		</div>
		
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($forums); ?>