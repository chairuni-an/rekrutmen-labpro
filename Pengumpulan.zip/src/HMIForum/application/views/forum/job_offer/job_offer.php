<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?= $breadcrumb ?>
		</div>

		<div class="col-md-12">
			<div class="page-header">
				<h1>Jobs Offer</h1>
			</div>
		</div>
		
		<div class="col-md-12">
			<table class="table table-striped table-condensed table-hover">
				<thead>
					<tr>
						<th style='width:65%'>Jobs Offer</th>
						<th style='width:35%'>Created</th>
					</tr>
				</thead>
				<tbody>
					<?php if ($jobs_offer) : ?>
						<?php foreach ($jobs_offer as $job_offer) : ?>
							<tr>
								<td>
									<p>
										<a href="<?= base_url('job_offer/' . $job_offer->slug) ?>"><?= $job_offer->title ?></a><br>
										<small style='overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical;'><?= $job_offer->description ?></small>
									</p>
								</td>
								<td>
									<p>
										by <a href="<?= base_url('user/profile/' . $job_offer->creator) ?>"><?= $job_offer->creator ?></a><br><?= $job_offer->created_at ?>
									</p>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
			
		</div>
		
		<?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) : ?>
			<div class="col-md-12">
				<a href="<?= base_url('create_job_offer') ?>" class="btn btn-default">Create a new job offer</a>
			</div>
		<?php endif; ?>
		
	</div><!-- .row -->
</div><!-- .container -->

<?php //var_dump($forums); ?>