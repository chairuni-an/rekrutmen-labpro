<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-2">
			<ul class="nav nav-pills nav-stacked">
				<li role="presentation""><a href="<?= base_url('admin/users') ?>">Users</a></li>
			</ul>
		</div>
	</div><!-- .row -->
</div><!-- .container -->