<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function create_user($username, $email, $password) {
		$data = array(
			'username' => $username,
			'email' => $email,
			'password' => password_hash($password, PASSWORD_BCRYPT),
			'created_at' => date('Y-m-j H:i:s'),
		);

		return $this->db->insert('users', $data);
	}

	public function check_login($username, $password) {
		$this->db->select('password');
		$this->db->from('users');
		$this->db->where('username', $username);
		$hash = $this->db->get()->row('password');

		return password_verify($password, $hash);
	}

	public function get_id_from_username($username) {
		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('username', $username);

		return $this->db->get()->row('id');
	}

	public function get_username_from_id($id) {
		$this->db->select('username');
		$this->db->from('users');
		$this->db->where('id', $id);

		return $this->db->get()->row('username');
	}

	public function get_user($id) {
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('id', $id);

		return $this->db->get()->row();
	}

}