<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forum extends CI_Controller {

	public function index($slug=false) {
		$data = new stdClass();

		if ($slug === false) {
			$forums = $this->forum_model->get_all_forum();

			foreach ($forums as $forum) {
				$forum->permalink = base_url($forum->slug);
				$forum->topics = $this->forum_model->get_forum_topics($forum->id);
				$forum->count_topics = count($forum->topics);
				$forum->count_posts = $this->forum_model->count_forum_posts($forum->id);

				if ($forum->count_topics > 0) {
					$forum->latest_topic = $this->forum_model->get_forum_latest_topic($forum->id);
					$forum->latest_topic->permalink = $forum->slug . '/' . $forum->latest_topic->slug;
					$forum->latest_topic->author = $this->user_model->get_username_from_id($forum->latest_topic->user_id);
				}
				else {
					$forum->latest_topic = new stdClass();
					$forum->latest_topic->permalink = null;
					$forum->latest_topic->title = null;
					$forum->latest_topic->author = null;
					$forum->latest_topic->created_at = null;
				}
			}

			$breadcrumb = '<ol class="breadcrumb">';
			$breadcrumb .= '<li class="active">Home</li>';
			$breadcrumb .= '</ol>';

			$data->forums = $forums;
			$data->breadcrumb = $breadcrumb;

			$this->load->view('header');
			$this->load->view('forum/forum/forum', $data);
		}
		else {
			$forum_id = $this->forum_model->get_forum_id_from_slug($slug);
			$forum = $this->forum_model->get_forum($forum_id);
			$topics = $this->forum_model->get_forum_topics($forum_id);

			$breadcrumb = '<ol class="breadcrumb">';
			$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
			$breadcrumb .= '<li class="active">' . $forum->title . '</li>';
			$breadcrumb .= '</ol>';

			foreach ($topics as $topic) {
				$topic->author = $this->user_model->get_username_from_id($topic->user_id);
				$topic->permalink = $slug . '/' . $topic->slug;
				$topic->posts = $this->forum_model->get_topic_posts($topic->id);
				$topic->count_posts = count($topic->posts);
				$topic->latest_post = $this->forum_model->get_topic_latest_post($topic->id);
				$topic->latest_post->author = $this->user_model->get_username_from_id($topic->latest_post->user_id);
			}

			$data->forum = $forum;
			$data->topics = $topics;
			$data->breadcrumb = $breadcrumb;

			$this->load->view('header');
			$this->load->view('forum/topic/topic', $data);
		}
	}

	public function topic($forum_slug, $topic_slug) {
		$data = new stdClass();

		$forum_id = $this->forum_model->get_forum_id_from_slug($forum_slug);
		$topic_id = $this->forum_model->get_topic_id_from_slug($topic_slug);

		$forum = $this->forum_model->get_forum($forum_id);
		$topic = $this->forum_model->get_topic($topic_id);
		$posts = $this->forum_model->get_topic_posts($topic_id);

		foreach ($posts as $post) {
			$post->author = $this->user_model->get_username_from_id($post->user_id);
		}

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li><a href="' . base_url($forum->slug) . '">' . $forum->title . '</a></li>';
		$breadcrumb .= '<li class="active">' . $topic->title . '</li>';
		$breadcrumb .= '</ol>';

		$data->forum = $forum;
		$data->topic = $topic;
		$data->posts = $posts;
		$data->breadcrumb = $breadcrumb;

		$this->load->view('header');
		$this->load->view('forum/post/post', $data);
	}

	public function create_forum() {
		$data = new stdClass();

		if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
			$data->is_admin = false;
		}
		else {
			$data->is_admin = true;
		}

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li class="active">Create a new forum</li>';
		$breadcrumb .= '</ol>';

		$data->breadcrumb = $breadcrumb;

		$this->form_validation->set_rules('title', 'Forum Title', 'required|alpha_numeric_spaces|min_length[4]|max_length[20]|is_unique[forums.title]', array('is_unique' => 'The forum title you entered already exists. Please choose another forum title.'));
		$this->form_validation->set_rules('description', 'Description', 'alpha_numeric_spaces|max_length[80]');

		if ($this->form_validation->run() === true) {
			$title = $this->input->post('title');
			$description = $this->input->post('description');

			if ($this->forum_model->create_forum($title, $description)) {
				$this->load->view('header');
				$this->load->view('forum/forum/create_success');
			}
			else {
				$data->error = 'There was a problem creating the new forum. Please try again.';

				$this->load->view('header');
				$this->load->view('forum/forum/create', $data);
			}
		}
		else {
			$data->title = $this->input->post('title');
			$data->description = $this->input->post('description');

			$this->load->view('header');
			$this->load->view('forum/forum/create', $data);
		}
	}

	public function create_topic($forum_slug) {
		$data = new stdClass();

		if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] != true) {
			$data->is_login = false;
		}
		else {
			$data->is_login = true;
		}

		$forum_slug = $this->uri->segment(1);
		$forum_id = $this->forum_model->get_forum_id_from_slug($forum_slug);
		$forum = $this->forum_model->get_forum($forum_id);

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li><a href="' . base_url($forum->slug) . '">' . $forum->title . '</a></li>';
		$breadcrumb .= '<li class="active">Create a new topic</li>';
		$breadcrumb .= '</ol>';

		$data->breadcrumb = $breadcrumb;

		$this->form_validation->set_rules('title', 'Topic Title', 'required|min_length[4]|max_length[20]|is_unique[topics.title]', array('is_unique' => 'The topic title you entered already exists. Please enter another topic title.'));
		$this->form_validation->set_rules('content', 'Content', 'required|min_length[4]');

		if ($this->form_validation->run() === true) {
			$user_id = $_SESSION['user_id'];
			$title = $this->input->post('title');
			$content = $this->input->post('content');

			if ($this->forum_model->create_topic($title, $user_id, $forum_id, $content)) {
				redirect(base_url($forum_slug . '/' . strtolower(url_title($title))));
			}
			else {
				$data->error = 'There was a problem creating your new account. Please try again';

				$this->load->view('header');
				$this->load->view('forum/topic/create', $data);
			}
		}
		else {
			$data->title = $this->input->post('title');
			$data->content = $this->input->post('content');

			$this->load->view('header');
			$this->load->view('forum/topic/create', $data);
		}
	}

	public function create_post($forum_slug, $topic_slug) {
		$data = new stdClass();

		if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] != true) {
			$data->is_login = false;
		}
		else {
			$data->is_login = true;
		}

		$forum_id = $this->forum_model->get_forum_id_from_slug($forum_slug);
		$topic_id = $this->forum_model->get_topic_id_from_slug($topic_slug);

		$forum = $this->forum_model->get_forum($forum_id);
		$topic = $this->forum_model->get_topic($topic_id);
		$posts = $this->forum_model->get_topic_posts($topic_id);

		foreach ($posts as $post) {
			$post->author = $this->user_model->get_username_from_id($post->user_id);
		}

		$breadcrumb = '<ol class="breadcrumb">';
		$breadcrumb .= '<li><a href="' . base_url() . '">Home</a></li>';
		$breadcrumb .= '<li><a href="' . base_url($forum->slug) . '">' . $forum->title . '</a></li>';
		$breadcrumb .= '<li class="active">' . $topic->title . '</li>';
		$breadcrumb .= '</ol>';

		$data->forum = $forum;
		$data->topic = $topic;
		$data->posts = $posts;
		$data->breadcrumb = $breadcrumb;

		$this->form_validation->set_rules('reply', 'Reply', 'required|min_length[1]');

		if ($this->form_validation->run() === true) {
			$user_id = $_SESSION['user_id'];
			$content = $this->input->post('reply');

			if ($this->forum_model->create_post($content, $user_id, $topic_id)) {
				redirect(base_url($forum_slug . '/' . $topic_slug));
			}
			else {
				$data->error = 'There was a problem creating your reply. Please try again.';

				$this->load->view('header');
				$this->load->view('forum/post/reply', $data);
			}
		}
		else {
			$data->content = $this->input->post('reply');

			$this->load->view('header');
			$this->load->view('forum/post/reply', $data);
		}
	}

}