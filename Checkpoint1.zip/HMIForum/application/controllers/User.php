<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index() {
		$this->login();
	}

	public function profile() {
		
	}

	public function register() {
		$data = new stdClass();

		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[4]|max_length[20]|is_unique[users.username]', array('is_unique' => 'This username already exists. Please choose another username.'));
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]', array('is_unique' => 'This email already being used. Please choose another email'));
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'required|min_length[6]|matches[password]');

		if ($this->form_validation->run() === true) {
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$password = $this->input->post('password');

			if ($this->user_model->create_user($username, $email, $password)) {
				$this->load->view('header');
				$this->load->view('user/register/register_success');
			}
			else {
				$data->error = 'There was a problem creating your new account. Please try again.';

				$this->load->view('header');
				$this->load->view('user/register/register', $data);
			}
		}
		else {
			$this->load->view('header');
			$this->load->view('user/register/register');
		}
	}

	public function login() {
		$data = new stdClass();

		$this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if ($this->form_validation->run() == true) {
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			if ($this->user_model->check_login($username, $password)) {
				$user_id = $this->user_model->get_id_from_username($username);
				$user = $this->user_model->get_user($user_id);

				$_SESSION['user_id'] = (int)$user->id;
				$_SESSION['username'] = (string)$user->username;
				$_SESSION['logged_in'] = (bool)true;
				$_SESSION['is_confirmed'] = (bool)$user->is_confirmed;
				$_SESSION['is_admin'] = (bool)$user->is_admin;

				$this->load->view('header');
				$this->load->view('user/login/login_success');
			}
			else {
				$data->error = "Wrong username and password.";

				$this->load->view('header');
				$this->load->view('user/login/login', $data);
			}
		}
		else {
			$this->load->view('header');
			$this->load->view('user/login/login');
		}
	}

	public function logout() {
		$data = new stdClass();

		if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
			foreach ($_SESSION as $key => $value) {
				unset($_SESSION[$key]);
			}

			$this->load->view('header');
			$this->load->view('user/logout/logout_success');
		}
		else {
			redirect('/');
		}
	}

}